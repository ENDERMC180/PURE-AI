import { Router, Request, Response, NextFunction } from "express";
import { db } from "@workspace/db";
import {
  conversations as conversationsTable,
  messages as messagesTable,
} from "@workspace/db";
import {
  CreateGeminiConversationBody,
  GetGeminiConversationParams,
  DeleteGeminiConversationParams,
  ListGeminiMessagesParams,
  SendGeminiMessageParams,
  SendGeminiMessageBody,
  GenerateGeminiImageBody,
} from "@workspace/api-zod";
import { ai } from "@workspace/integrations-gemini-ai";
import { generateImage } from "@workspace/integrations-gemini-ai/image";
import { eq, and } from "drizzle-orm";
import { getAuth } from "@clerk/express";

const router = Router();

const requireAuth = (req: Request, res: Response, next: NextFunction) => {
  const auth = getAuth(req);
  const userId = (auth?.sessionClaims?.userId as string | undefined) || auth?.userId;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  (req as Request & { userId: string }).userId = userId;
  next();
};

async function generateTitle(userMessage: string): Promise<string> {
  try {
    const result = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        {
          role: "user",
          parts: [
            {
              text: `Generate a very short, concise title (max 6 words) for a conversation that starts with this message. Return ONLY the title text, no quotes, no punctuation at the end:\n\n"${userMessage}"`,
            },
          ],
        },
      ],
      config: { maxOutputTokens: 30 },
    });
    const title = result.text?.trim().replace(/^["']|["']$/g, "") || userMessage.slice(0, 50);
    return title.length > 60 ? title.slice(0, 57) + "..." : title;
  } catch {
    return userMessage.slice(0, 50);
  }
}

router.get("/conversations", requireAuth, async (req, res) => {
  const userId = (req as Request & { userId: string }).userId;
  const result = await db
    .select()
    .from(conversationsTable)
    .where(eq(conversationsTable.userId, userId))
    .orderBy(conversationsTable.createdAt);
  res.json(result);
});

router.post("/conversations", requireAuth, async (req, res) => {
  const userId = (req as Request & { userId: string }).userId;
  const parsed = CreateGeminiConversationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }
  const [conversation] = await db
    .insert(conversationsTable)
    .values({ title: parsed.data.title, userId })
    .returning();
  res.status(201).json(conversation);
});

router.get("/conversations/:id", requireAuth, async (req, res) => {
  const userId = (req as Request & { userId: string }).userId;
  const parsed = GetGeminiConversationParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  const [conversation] = await db
    .select()
    .from(conversationsTable)
    .where(and(eq(conversationsTable.id, parsed.data.id), eq(conversationsTable.userId, userId)));
  if (!conversation) {
    res.status(404).json({ error: "Not found" });
    return;
  }
  const msgs = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.conversationId, parsed.data.id))
    .orderBy(messagesTable.createdAt);
  res.json({ ...conversation, messages: msgs });
});

router.patch("/conversations/:id", requireAuth, async (req, res) => {
  const userId = (req as Request & { userId: string }).userId;
  const id = Number(req.params.id);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  const { title } = req.body;
  if (!title || typeof title !== "string") {
    res.status(400).json({ error: "title is required" });
    return;
  }
  const [existing] = await db
    .select()
    .from(conversationsTable)
    .where(and(eq(conversationsTable.id, id), eq(conversationsTable.userId, userId)));
  if (!existing) {
    res.status(404).json({ error: "Not found" });
    return;
  }
  const [updated] = await db
    .update(conversationsTable)
    .set({ title: title.slice(0, 100) })
    .where(eq(conversationsTable.id, id))
    .returning();
  res.json(updated);
});

router.delete("/conversations/:id", requireAuth, async (req, res) => {
  const userId = (req as Request & { userId: string }).userId;
  const parsed = DeleteGeminiConversationParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  const [existing] = await db
    .select()
    .from(conversationsTable)
    .where(and(eq(conversationsTable.id, parsed.data.id), eq(conversationsTable.userId, userId)));
  if (!existing) {
    res.status(404).json({ error: "Not found" });
    return;
  }
  await db.delete(messagesTable).where(eq(messagesTable.conversationId, parsed.data.id));
  await db.delete(conversationsTable).where(eq(conversationsTable.id, parsed.data.id));
  res.status(204).send();
});

router.get("/conversations/:id/messages", requireAuth, async (req, res) => {
  const userId = (req as Request & { userId: string }).userId;
  const parsed = ListGeminiMessagesParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  const [conversation] = await db
    .select()
    .from(conversationsTable)
    .where(and(eq(conversationsTable.id, parsed.data.id), eq(conversationsTable.userId, userId)));
  if (!conversation) {
    res.status(404).json({ error: "Not found" });
    return;
  }
  const msgs = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.conversationId, parsed.data.id))
    .orderBy(messagesTable.createdAt);
  res.json(msgs);
});

router.post("/conversations/:id/messages", requireAuth, async (req, res) => {
  const userId = (req as Request & { userId: string }).userId;
  const paramsParsed = SendGeminiMessageParams.safeParse({ id: Number(req.params.id) });
  const bodyParsed = SendGeminiMessageBody.safeParse(req.body);

  if (!paramsParsed.success || !bodyParsed.success) {
    res.status(400).json({ error: "Invalid request" });
    return;
  }

  const conversationId = paramsParsed.data.id;
  const userContent = bodyParsed.data.content;

  const [conversation] = await db
    .select()
    .from(conversationsTable)
    .where(and(eq(conversationsTable.id, conversationId), eq(conversationsTable.userId, userId)));

  if (!conversation) {
    res.status(404).json({ error: "Not found" });
    return;
  }

  await db.insert(messagesTable).values({ conversationId, role: "user", content: userContent });

  const chatMessages = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.conversationId, conversationId))
    .orderBy(messagesTable.createdAt);

  const isFirstMessage = chatMessages.length === 1;

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  let fullResponse = "";

  const systemInstruction = `You are PureAI, a smart and helpful AI assistant.

OWNER INFORMATION:
- Your owner and creator is FurypieX.
- If anyone asks who made you, who owns you, or who your owner/creator is, always answer: "Mera owner FurypieX hai. Wo ek hosting developer, server developer, aur YouTuber hain — aur bohut acche insaan bhi hain! 😊"
- You can say this in whatever language the user is speaking.

LANGUAGE RULE (VERY IMPORTANT):
- Always detect the language the user is writing in.
- Always reply in that exact same language.
- If the user writes in Hindi, reply in Hindi.
- If the user writes in English, reply in English.
- If the user writes in Hinglish (mixed Hindi+English), reply in Hinglish.
- If the user writes in Urdu, reply in Urdu.
- If the user writes in any other language, reply in that language.
- Never switch languages unless the user switches first.

Be helpful, friendly, and conversational.`;

  try {
    const stream = await ai.models.generateContentStream({
      model: "gemini-2.5-flash",
      contents: chatMessages.map((m) => ({
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: m.content }],
      })),
      config: {
        maxOutputTokens: 8192,
        systemInstruction,
      },
    });

    for await (const chunk of stream) {
      const text = chunk.text;
      if (text) {
        fullResponse += text;
        res.write(`data: ${JSON.stringify({ content: text })}\n\n`);
      }
    }

    await db.insert(messagesTable).values({ conversationId, role: "assistant", content: fullResponse });

    if (isFirstMessage) {
      const newTitle = await generateTitle(userContent);
      await db
        .update(conversationsTable)
        .set({ title: newTitle })
        .where(eq(conversationsTable.id, conversationId));
      res.write(`data: ${JSON.stringify({ done: true, title: newTitle })}\n\n`);
    } else {
      res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    }

    res.end();
  } catch (error) {
    req.log.error({ error }, "Error generating content");
    res.write(`data: ${JSON.stringify({ error: "Generation failed" })}\n\n`);
    res.end();
  }
});

router.post("/generate-image", requireAuth, async (req, res) => {
  const parsed = GenerateGeminiImageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }
  try {
    const { b64_json, mimeType } = await generateImage(parsed.data.prompt);
    res.json({ b64_json, mimeType });
  } catch (error) {
    req.log.error({ error }, "Error generating image");
    res.status(500).json({ error: "Image generation failed" });
  }
});

export default router;
