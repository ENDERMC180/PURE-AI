import { useState, useCallback, useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { getGetGeminiConversationQueryKey, getListGeminiMessagesQueryKey, type GeminiMessage } from "@workspace/api-client-react";

interface UseChatStreamOptions {
  conversationId: number;
  onFinished?: () => void;
  onError?: (error: Error) => void;
}

export function useChatStream({ conversationId, onFinished, onError }: UseChatStreamOptions) {
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamedContent, setStreamedContent] = useState("");
  const abortControllerRef = useRef<AbortController | null>(null);
  const queryClient = useQueryClient();

  const stopStreaming = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
      setIsStreaming(false);
    }
  }, []);

  const sendMessage = useCallback(async (content: string) => {
    if (isStreaming) return;

    setIsStreaming(true);
    setStreamedContent("");
    abortControllerRef.current = new AbortController();

    const BASE = import.meta.env.BASE_URL;
    
    // Optimistically update the UI with the user's message
    const userMessage: GeminiMessage = {
      id: Date.now(), // Temporary ID
      conversationId,
      role: "user",
      content,
      createdAt: new Date().toISOString(),
    };

    // We'll also create a temporary assistant message to hold the stream
    const tempAssistantMessageId = Date.now() + 1;

    queryClient.setQueryData<GeminiMessage[]>(getListGeminiMessagesQueryKey(conversationId), (old) => {
      return [...(old || []), userMessage];
    });

    try {
      const response = await fetch(`${BASE}api/gemini/conversations/${conversationId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content }),
        signal: abortControllerRef.current.signal,
      });

      if (!response.ok) {
        throw new Error("Failed to send message");
      }

      if (!response.body) {
        throw new Error("No response body");
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let fullContent = "";

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";
        
        for (const line of lines) {
          if (line.startsWith("data: ")) {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.done) {
                // Invalidate to get the final real messages from the DB
                queryClient.invalidateQueries({ queryKey: getListGeminiMessagesQueryKey(conversationId) });
                queryClient.invalidateQueries({ queryKey: getGetGeminiConversationQueryKey(conversationId) });
                if (onFinished) onFinished();
              } else if (data.content) {
                fullContent += data.content;
                setStreamedContent(fullContent);
              }
            } catch (e) {
              console.error("Error parsing SSE data", e);
            }
          }
        }
      }
    } catch (error: any) {
      if (error.name === 'AbortError') {
        console.log('Stream aborted');
        // Still invalidate to get whatever was saved
        queryClient.invalidateQueries({ queryKey: getListGeminiMessagesQueryKey(conversationId) });
      } else {
        console.error("Stream error:", error);
        if (onError) onError(error);
      }
    } finally {
      setIsStreaming(false);
      abortControllerRef.current = null;
    }
  }, [conversationId, isStreaming, queryClient, onFinished, onError]);

  return {
    sendMessage,
    stopStreaming,
    isStreaming,
    streamedContent
  };
}
