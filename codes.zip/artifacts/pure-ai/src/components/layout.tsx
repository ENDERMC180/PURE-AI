import { ReactNode } from "react";
import { Sidebar } from "./chat/sidebar";

interface LayoutProps {
  children: ReactNode;
  currentChatId?: number;
}

export function Layout({ children, currentChatId }: LayoutProps) {
  return (
    <div className="flex h-[100dvh] w-full bg-background overflow-hidden">
      <Sidebar currentChatId={currentChatId} />
      <main className="flex-1 flex flex-col relative h-full max-w-full overflow-hidden">
        {children}
      </main>
    </div>
  );
}
