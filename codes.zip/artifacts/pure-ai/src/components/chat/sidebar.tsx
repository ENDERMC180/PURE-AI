import { Link, useLocation } from "wouter";
import { Plus, MessageSquare, Trash2, Menu, BrainCircuit, LogOut, User } from "lucide-react";
import { useListGeminiConversations, useCreateGeminiConversation, useDeleteGeminiConversation, getListGeminiConversationsQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useUser, useClerk } from "@clerk/react";

interface SidebarProps {
  currentChatId?: number;
}

export function Sidebar({ currentChatId }: SidebarProps) {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { user } = useUser();
  const { signOut } = useClerk();

  const { data: conversations, isLoading } = useListGeminiConversations();

  const createChat = useCreateGeminiConversation({
    mutation: {
      onSuccess: (newChat) => {
        queryClient.invalidateQueries({ queryKey: getListGeminiConversationsQueryKey() });
        setLocation(`/chat/${newChat.id}`);
      },
    },
  });

  const deleteChat = useDeleteGeminiConversation({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListGeminiConversationsQueryKey() });
      },
    },
  });

  const handleCreateNew = () => {
    createChat.mutate({ data: { title: "New Conversation" } });
  };

  const handleDelete = (e: React.MouseEvent, id: number) => {
    e.preventDefault();
    e.stopPropagation();
    deleteChat.mutate({ id });
    if (currentChatId === id) {
      setLocation("/chat");
    }
  };

  const handleSignOut = () => {
    signOut(() => setLocation("/"));
  };

  const SidebarContent = () => (
    <div className="flex h-full flex-col bg-sidebar border-r border-sidebar-border text-sidebar-foreground">
      <div className="p-4 flex items-center justify-between">
        <Link href="/chat" className="flex items-center gap-2 font-bold text-lg text-primary tracking-tight">
          <BrainCircuit className="w-5 h-5" />
          <span>PureAI</span>
        </Link>
      </div>

      <div className="px-3 pb-4">
        <Button
          onClick={handleCreateNew}
          disabled={createChat.isPending}
          className="w-full justify-start gap-2 shadow-sm font-medium"
        >
          <Plus className="w-4 h-4" />
          New chat
        </Button>
      </div>

      <ScrollArea className="flex-1 px-3">
        <div className="space-y-1 pb-4">
          <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
            History
          </div>
          {isLoading ? (
            <div className="p-4 text-center text-sm text-muted-foreground">Loading...</div>
          ) : conversations?.length === 0 ? (
            <div className="p-4 text-center text-sm text-muted-foreground">No conversations yet</div>
          ) : (
            conversations?.map((chat) => (
              <Link key={chat.id} href={`/chat/${chat.id}`}>
                <div
                  className={`
                  group flex items-center justify-between px-3 py-2 rounded-md text-sm cursor-pointer transition-colors
                  ${
                    currentChatId === chat.id
                      ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
                      : "hover:bg-sidebar-accent/50 text-sidebar-foreground/80 hover:text-sidebar-foreground"
                  }
                `}
                >
                  <div className="flex items-center gap-2 overflow-hidden">
                    <MessageSquare className="w-4 h-4 shrink-0 opacity-70" />
                    <span className="truncate">{chat.title || "New Conversation"}</span>
                  </div>
                  <button
                    onClick={(e) => handleDelete(e, chat.id)}
                    className="opacity-0 group-hover:opacity-100 p-1 hover:text-destructive transition-all rounded"
                    title="Delete chat"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </Link>
            ))
          )}
        </div>
      </ScrollArea>

      <div className="p-3 border-t border-sidebar-border">
        <div className="flex items-center gap-2 px-2 py-2 rounded-md">
          <div className="w-7 h-7 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
            {user?.imageUrl ? (
              <img src={user.imageUrl} alt={user.firstName || "User"} className="w-7 h-7 rounded-full object-cover" />
            ) : (
              <User className="w-3.5 h-3.5 text-primary" />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-medium truncate text-sidebar-foreground">
              {user?.firstName || user?.emailAddresses?.[0]?.emailAddress || "User"}
            </p>
            <p className="text-xs text-muted-foreground truncate">
              {user?.emailAddresses?.[0]?.emailAddress}
            </p>
          </div>
          <button
            onClick={handleSignOut}
            title="Sign out"
            className="p-1.5 rounded hover:bg-sidebar-accent/60 text-muted-foreground hover:text-sidebar-foreground transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <>
      <div className="hidden md:block w-64 h-[100dvh] shrink-0">
        <SidebarContent />
      </div>
      <div className="md:hidden absolute top-3 left-3 z-50">
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="h-9 w-9 bg-background/80 backdrop-blur-md">
              <Menu className="h-4 w-4" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0 w-72">
            <SidebarContent />
          </SheetContent>
        </Sheet>
      </div>
    </>
  );
}
