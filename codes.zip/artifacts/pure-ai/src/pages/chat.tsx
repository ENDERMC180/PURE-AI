import { useState, useEffect, useRef, useCallback } from "react";
import { useParams, useLocation } from "wouter";
import {
  Send,
  Square,
  Copy,
  RefreshCw,
  BrainCircuit,
  Check,
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  ImageIcon,
  Loader2,
} from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import {
  useGetGeminiConversation,
  getGetGeminiConversationQueryKey,
  getListGeminiConversationsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";

interface Message {
  id?: number;
  role: "user" | "assistant";
  content: string;
  streaming?: boolean;
  imageUrl?: string;
}

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

declare global {
  interface Window {
    SpeechRecognition: typeof SpeechRecognition;
    webkitSpeechRecognition: typeof SpeechRecognition;
  }
}

export default function ChatPage() {
  const params = useParams<{ id: string }>();
  const conversationId = Number(params.id);
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();

  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const [copiedId, setCopiedId] = useState<number | null>(null);
  const [speakingIdx, setSpeakingIdx] = useState<number | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [conversationTitle, setConversationTitle] = useState<string | null>(null);

  const abortRef = useRef<AbortController | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  const { data: conversation, isLoading } = useGetGeminiConversation(conversationId, {
    query: {
      queryKey: getGetGeminiConversationQueryKey(conversationId),
      enabled: !!conversationId,
    },
  });

  useEffect(() => {
    if (conversation?.messages) {
      setMessages(
        conversation.messages.map((m) => ({
          id: m.id,
          role: m.role as "user" | "assistant",
          content: m.content,
        }))
      );
    }
  }, [conversation?.messages]);

  useEffect(() => {
    const initialPrompt = sessionStorage.getItem(`initial_prompt_${conversationId}`);
    if (initialPrompt && conversation?.messages?.length === 0) {
      sessionStorage.removeItem(`initial_prompt_${conversationId}`);
      sendMessage(initialPrompt);
    }
  }, [conversationId, conversation]);

  const scrollToBottom = useCallback(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, scrollToBottom]);

  const sendMessage = useCallback(
    async (content: string) => {
      if (!content.trim() || isStreaming) return;

      const userMessage: Message = { role: "user", content: content.trim() };
      const assistantMessage: Message = { role: "assistant", content: "", streaming: true };

      setMessages((prev) => [...prev, userMessage, assistantMessage]);
      setInput("");
      setIsStreaming(true);

      if (textareaRef.current) {
        textareaRef.current.style.height = "auto";
      }

      const controller = new AbortController();
      abortRef.current = controller;

      try {
        const response = await fetch(
          `${BASE}/api/gemini/conversations/${conversationId}/messages`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ content: content.trim() }),
            signal: controller.signal,
            credentials: "include",
          }
        );

        if (!response.ok) {
          throw new Error("Failed to send message");
        }

        const reader = response.body!.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        let fullResponse = "";

        while (true) {
          const { value, done } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() ?? "";

          for (const line of lines) {
            if (line.startsWith("data: ")) {
              try {
                const data = JSON.parse(line.slice(6));
                if (data.done) {
                  setMessages((prev) =>
                    prev.map((m, i) =>
                      i === prev.length - 1 ? { ...m, streaming: false } : m
                    )
                  );
                  if (data.title) {
                    setConversationTitle(data.title);
                  }
                  queryClient.invalidateQueries({
                    queryKey: getGetGeminiConversationQueryKey(conversationId),
                  });
                  queryClient.invalidateQueries({
                    queryKey: getListGeminiConversationsQueryKey(),
                  });
                } else if (data.content) {
                  fullResponse += data.content;
                  setMessages((prev) =>
                    prev.map((m, i) =>
                      i === prev.length - 1 ? { ...m, content: fullResponse } : m
                    )
                  );
                  scrollToBottom();
                } else if (data.error) {
                  setMessages((prev) =>
                    prev.map((m, i) =>
                      i === prev.length - 1
                        ? { ...m, content: "Sorry, something went wrong. Please try again.", streaming: false }
                        : m
                    )
                  );
                }
              } catch {
                // skip malformed lines
              }
            }
          }
        }
      } catch (err: unknown) {
        if (err instanceof Error && err.name !== "AbortError") {
          setMessages((prev) =>
            prev.map((m, i) =>
              i === prev.length - 1
                ? { ...m, content: "Connection error. Please try again.", streaming: false }
                : m
            )
          );
        }
      } finally {
        setIsStreaming(false);
        abortRef.current = null;
      }
    },
    [conversationId, isStreaming, queryClient, scrollToBottom]
  );

  const handleGenerateImage = useCallback(async () => {
    if (!input.trim() || isStreaming || isGeneratingImage) return;
    const prompt = input.trim();
    setInput("");
    setIsGeneratingImage(true);

    const userMessage: Message = { role: "user", content: `🖼️ Generate image: ${prompt}` };
    const assistantMessage: Message = { role: "assistant", content: "", streaming: true };
    setMessages((prev) => [...prev, userMessage, assistantMessage]);

    try {
      const response = await fetch(`${BASE}/api/gemini/generate-image`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
        credentials: "include",
      });

      if (!response.ok) throw new Error("Image generation failed");

      const { b64_json, mimeType } = await response.json();
      const dataUrl = `data:${mimeType};base64,${b64_json}`;

      setMessages((prev) =>
        prev.map((m, i) =>
          i === prev.length - 1
            ? { ...m, content: `Here is the generated image for: **${prompt}**`, imageUrl: dataUrl, streaming: false }
            : m
        )
      );
    } catch {
      setMessages((prev) =>
        prev.map((m, i) =>
          i === prev.length - 1
            ? { ...m, content: "Sorry, image generation failed. Please try again.", streaming: false }
            : m
        )
      );
    } finally {
      setIsGeneratingImage(false);
    }
  }, [input, isStreaming, isGeneratingImage]);

  const handleStop = () => {
    abortRef.current?.abort();
    setIsStreaming(false);
    setMessages((prev) =>
      prev.map((m, i) =>
        i === prev.length - 1 && m.streaming ? { ...m, streaming: false } : m
      )
    );
  };

  const handleRegenerate = () => {
    const lastUserMessage = [...messages].reverse().find((m) => m.role === "user");
    if (!lastUserMessage) return;
    setMessages((prev) => prev.slice(0, -1));
    sendMessage(lastUserMessage.content);
  };

  const handleCopy = (content: string, idx: number) => {
    navigator.clipboard.writeText(content);
    setCopiedId(idx);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSpeak = (content: string, idx: number) => {
    window.speechSynthesis.cancel();

    if (speakingIdx === idx) {
      setSpeakingIdx(null);
      return;
    }

    const plainText = content.replace(/[#*`_~\[\]()>!]/g, " ").replace(/\s+/g, " ").trim();
    const utterance = new SpeechSynthesisUtterance(plainText);
    utterance.rate = 1;
    utterance.pitch = 1;
    utterance.onend = () => setSpeakingIdx(null);
    utterance.onerror = () => setSpeakingIdx(null);
    utteranceRef.current = utterance;

    setSpeakingIdx(idx);
    window.speechSynthesis.speak(utterance);
  };

  const handleVoiceInput = () => {
    const SpeechRecognitionAPI =
      window.SpeechRecognition || window.webkitSpeechRecognition;

    if (!SpeechRecognitionAPI) {
      alert("Voice input is not supported in your browser. Please use Chrome.");
      return;
    }

    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    const recognition = new SpeechRecognitionAPI();
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.lang = "auto";

    recognition.onresult = (event) => {
      let transcript = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        transcript += event.results[i][0].transcript;
      }
      setInput(transcript);
      if (textareaRef.current) {
        textareaRef.current.style.height = "auto";
        textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
      }
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognition.onerror = () => {
      setIsListening(false);
    };

    recognitionRef.current = recognition;
    recognition.start();
    setIsListening(true);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
    e.target.style.height = "auto";
    e.target.style.height = `${Math.min(e.target.scrollHeight, 200)}px`;
  };

  if (!conversationId || isNaN(conversationId)) {
    setLocation("/chat");
    return null;
  }

  const displayTitle = conversationTitle ?? conversation?.title ?? "New Conversation";

  return (
    <Layout currentChatId={conversationId}>
      <div className="flex flex-col h-full">
        <div className="border-b border-border px-4 py-3 flex items-center gap-3 shrink-0">
          <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center">
            <BrainCircuit className="w-4 h-4 text-primary-foreground" />
          </div>
          <span className="font-semibold text-sm text-foreground truncate">
            {isLoading ? "Loading..." : displayTitle}
          </span>
        </div>

        <ScrollArea className="flex-1 px-4 py-4">
          <div className="max-w-3xl mx-auto space-y-6 pb-4">
            {isLoading ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="flex gap-3">
                    <Skeleton className="w-8 h-8 rounded-full shrink-0" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-4 w-3/4" />
                      <Skeleton className="h-4 w-1/2" />
                    </div>
                  </div>
                ))}
              </div>
            ) : messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center">
                  <BrainCircuit className="w-6 h-6 text-primary" />
                </div>
                <p className="text-muted-foreground text-sm">Ask anything or use the mic to speak</p>
              </div>
            ) : (
              messages.map((message, idx) => (
                <div
                  key={idx}
                  className={`flex gap-3 ${message.role === "user" ? "justify-end" : "justify-start"}`}
                  data-testid={`message-${idx}`}
                >
                  {message.role === "assistant" && (
                    <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center shrink-0 mt-0.5">
                      <BrainCircuit className="w-4 h-4 text-primary-foreground" />
                    </div>
                  )}

                  <div className={`group max-w-[85%] ${message.role === "user" ? "max-w-[75%]" : ""}`}>
                    {message.role === "user" ? (
                      <div className="bg-primary text-primary-foreground rounded-2xl rounded-tr-sm px-4 py-2.5 text-sm leading-relaxed">
                        {message.content}
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <div className="prose prose-sm max-w-none text-foreground dark:prose-invert prose-p:leading-relaxed prose-pre:bg-muted prose-pre:rounded-lg prose-code:text-primary">
                          {message.content ? (
                            <ReactMarkdown remarkPlugins={[remarkGfm]}>
                              {message.content}
                            </ReactMarkdown>
                          ) : message.streaming ? (
                            <div className="flex gap-1 py-1">
                              <span className="w-2 h-2 bg-primary/60 rounded-full animate-bounce [animation-delay:-0.3s]" />
                              <span className="w-2 h-2 bg-primary/60 rounded-full animate-bounce [animation-delay:-0.15s]" />
                              <span className="w-2 h-2 bg-primary/60 rounded-full animate-bounce" />
                            </div>
                          ) : null}
                          {message.streaming && message.content && (
                            <span className="inline-block w-0.5 h-4 bg-primary animate-pulse ml-0.5 align-middle" />
                          )}
                        </div>

                        {message.imageUrl && (
                          <div className="mt-2 rounded-xl overflow-hidden border border-border max-w-sm">
                            <img
                              src={message.imageUrl}
                              alt="AI generated"
                              className="w-full h-auto object-contain"
                            />
                          </div>
                        )}

                        {!message.streaming && message.content && (
                          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button
                              onClick={() => handleSpeak(message.content, idx)}
                              className={`flex items-center gap-1 text-xs px-2 py-1 rounded-md hover:bg-muted transition-colors ${
                                speakingIdx === idx
                                  ? "text-primary"
                                  : "text-muted-foreground hover:text-foreground"
                              }`}
                              title={speakingIdx === idx ? "Stop speaking" : "Read aloud"}
                            >
                              {speakingIdx === idx ? (
                                <VolumeX className="w-3.5 h-3.5" />
                              ) : (
                                <Volume2 className="w-3.5 h-3.5" />
                              )}
                            </button>

                            <button
                              onClick={() => handleCopy(message.content, idx)}
                              className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground px-2 py-1 rounded-md hover:bg-muted transition-colors"
                              data-testid={`copy-button-${idx}`}
                            >
                              {copiedId === idx ? (
                                <Check className="w-3.5 h-3.5" />
                              ) : (
                                <Copy className="w-3.5 h-3.5" />
                              )}
                              {copiedId === idx ? "Copied" : "Copy"}
                            </button>

                            {idx === messages.length - 1 && (
                              <button
                                onClick={handleRegenerate}
                                disabled={isStreaming}
                                className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground px-2 py-1 rounded-md hover:bg-muted transition-colors disabled:opacity-50"
                                data-testid="regenerate-button"
                              >
                                <RefreshCw className="w-3.5 h-3.5" />
                                Regenerate
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
            <div ref={bottomRef} />
          </div>
        </ScrollArea>

        <div className="px-4 py-4 border-t border-border bg-background shrink-0">
          <div className="max-w-3xl mx-auto">
            <div className="flex items-end gap-2 rounded-xl border border-border bg-card shadow-sm px-3 py-2 focus-within:border-primary/50 focus-within:ring-1 focus-within:ring-primary/20 transition-all">
              <button
                onClick={handleVoiceInput}
                disabled={isStreaming || isGeneratingImage}
                className={`shrink-0 h-8 w-8 flex items-center justify-center rounded-lg transition-colors disabled:opacity-50 ${
                  isListening
                    ? "bg-red-500/20 text-red-400 animate-pulse"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                }`}
                title={isListening ? "Stop listening" : "Voice input"}
              >
                {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </button>

              <textarea
                ref={textareaRef}
                value={input}
                onChange={handleInputChange}
                onKeyDown={handleKeyDown}
                placeholder={isListening ? "Listening..." : "Message PureAI..."}
                rows={1}
                className="flex-1 bg-transparent resize-none text-sm text-foreground placeholder:text-muted-foreground outline-none max-h-48 py-1.5 leading-relaxed"
                data-testid="message-input"
              />

              <button
                onClick={handleGenerateImage}
                disabled={!input.trim() || isStreaming || isGeneratingImage}
                className="shrink-0 h-8 w-8 flex items-center justify-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors disabled:opacity-30"
                title="Generate image from prompt"
              >
                {isGeneratingImage ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <ImageIcon className="w-4 h-4" />
                )}
              </button>

              {isStreaming ? (
                <Button
                  onClick={handleStop}
                  size="icon"
                  variant="destructive"
                  className="h-8 w-8 shrink-0 rounded-lg"
                  data-testid="stop-button"
                >
                  <Square className="w-3.5 h-3.5" />
                </Button>
              ) : (
                <Button
                  onClick={() => sendMessage(input)}
                  size="icon"
                  disabled={!input.trim() || isGeneratingImage}
                  className="h-8 w-8 shrink-0 rounded-lg"
                  data-testid="send-button"
                >
                  <Send className="w-3.5 h-3.5" />
                </Button>
              )}
            </div>
            <p className="text-center text-xs text-muted-foreground mt-2">
              PureAI can make mistakes. Use mic for voice input, 🖼️ for image generation.
            </p>
          </div>
        </div>
      </div>
    </Layout>
  );
}
