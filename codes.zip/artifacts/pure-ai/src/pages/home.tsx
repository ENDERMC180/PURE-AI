import { useLocation } from "wouter";
import { BrainCircuit, ArrowRight } from "lucide-react";
import { useCreateGeminiConversation, getListGeminiConversationsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Layout } from "@/components/layout";

const SUGGESTED_PROMPTS = [
  "Explain quantum entanglement in simple terms",
  "Write a short story about a time traveler",
  "Help me debug a React useEffect bug",
  "What are the best strategies for deep focus?",
  "Summarize the history of the Roman Empire",
  "Create a 7-day workout plan for beginners",
];

export default function Home() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();

  const createChat = useCreateGeminiConversation({
    mutation: {
      onSuccess: (newChat) => {
        queryClient.invalidateQueries({ queryKey: getListGeminiConversationsQueryKey() });
        setLocation(`/chat/${newChat.id}`);
      },
    },
  });

  const handlePromptClick = (prompt: string) => {
    createChat.mutate(
      { data: { title: prompt.slice(0, 60) } },
      {
        onSuccess: (newChat) => {
          queryClient.invalidateQueries({ queryKey: getListGeminiConversationsQueryKey() });
          sessionStorage.setItem(`initial_prompt_${newChat.id}`, prompt);
          setLocation(`/chat/${newChat.id}`);
        },
      }
    );
  };

  return (
    <Layout>
      <div className="flex flex-1 flex-col items-center justify-center px-4 py-12 h-full overflow-y-auto">
        <div className="w-full max-w-2xl flex flex-col items-center gap-8">
          <div className="flex flex-col items-center gap-3">
            <div className="w-14 h-14 rounded-2xl bg-primary flex items-center justify-center shadow-lg">
              <BrainCircuit className="w-8 h-8 text-primary-foreground" />
            </div>
            <h1 className="text-3xl font-bold tracking-tight text-foreground">PureAI</h1>
            <p className="text-muted-foreground text-center text-sm max-w-sm">
              Your personal AI assistant — powered by Gemini. Think clearly, create freely, explore anything.
            </p>
          </div>

          <div className="w-full grid grid-cols-1 sm:grid-cols-2 gap-3">
            {SUGGESTED_PROMPTS.map((prompt, i) => (
              <button
                key={i}
                onClick={() => handlePromptClick(prompt)}
                disabled={createChat.isPending}
                className="group flex items-start justify-between gap-3 rounded-xl border border-border bg-card px-4 py-3.5 text-left text-sm text-card-foreground hover:border-primary/40 hover:bg-primary/5 transition-all duration-150 disabled:opacity-50"
                data-testid={`suggested-prompt-${i}`}
              >
                <span className="font-medium leading-snug">{prompt}</span>
                <ArrowRight className="w-4 h-4 shrink-0 mt-0.5 text-muted-foreground group-hover:text-primary transition-colors" />
              </button>
            ))}
          </div>

          <p className="text-xs text-muted-foreground text-center">
            Click a prompt or start a new chat from the sidebar
          </p>
        </div>
      </div>
    </Layout>
  );
}
