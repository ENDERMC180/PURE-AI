import { Link } from "wouter";
import { BrainCircuit, Zap, Lock, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Landing() {
  return (
    <div className="min-h-[100dvh] flex flex-col bg-background text-foreground">
      <header className="flex items-center justify-between px-6 py-4 border-b border-border">
        <div className="flex items-center gap-2 font-bold text-lg text-primary">
          <BrainCircuit className="w-5 h-5" />
          <span>PureAI</span>
        </div>
        <div className="flex items-center gap-3">
          <Link href="/sign-in">
            <Button variant="ghost" size="sm">Sign in</Button>
          </Link>
          <Link href="/sign-up">
            <Button size="sm">Get started</Button>
          </Link>
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center px-6 py-16 text-center">
        <div className="max-w-2xl flex flex-col items-center gap-8">
          <div className="flex flex-col items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-primary flex items-center justify-center shadow-lg">
              <BrainCircuit className="w-9 h-9 text-primary-foreground" />
            </div>
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight">
              Your personal AI,{" "}
              <span className="text-primary">reimagined</span>
            </h1>
            <p className="text-muted-foreground text-lg max-w-lg">
              PureAI gives you a private AI assistant powered by Gemini — with your own conversation history, accessible only to you.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3">
            <Link href="/sign-up">
              <Button size="lg" className="px-8">Start for free</Button>
            </Link>
            <Link href="/sign-in">
              <Button size="lg" variant="outline" className="px-8">Sign in</Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-4 text-left">
            <div className="flex flex-col gap-2 p-5 rounded-xl border border-border bg-card">
              <Zap className="w-5 h-5 text-primary" />
              <h3 className="font-semibold text-sm">Real-time streaming</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Watch responses generate instantly with live streaming, just like the leading AI assistants.
              </p>
            </div>
            <div className="flex flex-col gap-2 p-5 rounded-xl border border-border bg-card">
              <MessageSquare className="w-5 h-5 text-primary" />
              <h3 className="font-semibold text-sm">Conversation history</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">
                All your chats are saved and organized. Pick up right where you left off, anytime.
              </p>
            </div>
            <div className="flex flex-col gap-2 p-5 rounded-xl border border-border bg-card">
              <Lock className="w-5 h-5 text-primary" />
              <h3 className="font-semibold text-sm">Private to you</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Your conversations are private and tied to your account — no one else can see them.
              </p>
            </div>
          </div>
        </div>
      </main>

      <footer className="text-center py-6 text-xs text-muted-foreground border-t border-border">
        PureAI — powered by Gemini
      </footer>
    </div>
  );
}
